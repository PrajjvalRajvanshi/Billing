package com.cg.mobilebilling.stepdefinition;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ChangePlanStepDefinition {
	@Given("^User is on changePlanPage Page$")
	public void user_is_on_changePlanPage_Page() throws Throwable {
	    
	}

	@When("^User enter his correct credentials and click on change plan button$")
	public void user_enter_his_correct_credentials_and_click_on_change_plan_button() throws Throwable {
	  
	}

	@Then("^User is redirected to changePlanPage page and message gets displayed$")
	public void user_is_redirected_to_changePlanPage_page_and_message_gets_displayed() throws Throwable {
	  
	}
}
