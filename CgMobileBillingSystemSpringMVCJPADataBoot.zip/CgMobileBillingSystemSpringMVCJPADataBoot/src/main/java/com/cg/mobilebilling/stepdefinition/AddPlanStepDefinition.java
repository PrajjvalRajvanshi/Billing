package com.cg.mobilebilling.stepdefinition;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AddPlanStepDefinition {
	@Given("^User is on addPlansPage Page$")
	public void user_is_on_addPlansPage_Page() throws Throwable {
	   
	}

	@When("^User enter the details and click on submit button$")
	public void user_enter_the_details_and_click_on_submit_button() throws Throwable {
	 
	}

	@Then("^User is redirected to addPlansPage page and message gets displayed$")
	public void user_is_redirected_to_addPlansPage_page_and_message_gets_displayed() throws Throwable {
	   
	}

	@When("^User click on home page button$")
	public void user_click_on_home_page_button() throws Throwable {
	   
	}

	@Then("^User is redirected to home page$")
	public void user_is_redirected_to_home_page() throws Throwable {
	   
	}
}
